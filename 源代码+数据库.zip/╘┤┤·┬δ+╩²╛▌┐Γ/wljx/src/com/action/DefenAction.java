package com.action;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.dao.DefenDao;
import com.opensymphony.xwork2.ActionSupport;

/**
 *Created by pxc on 2018年5月20日 上午10:06:17
 * 
 */

public class DefenAction extends ActionSupport{
	
	private DefenDao defenDao;
	
	public String getList(){
		String hql = "from Defen ";
		List defenList = defenDao.getHibernateTemplate().find(hql);
		ServletActionContext.getRequest().setAttribute("defenList", defenList);
		return SUCCESS;
	}

	public DefenDao getDefenDao() {
		return defenDao;
	}

	public void setDefenDao(DefenDao defenDao) {
		this.defenDao = defenDao;
	}

	
}
