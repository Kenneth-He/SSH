package com.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.dao.TDocDAO;
import com.dao.TShitiDAO;
import com.model.TDoc;
import com.model.TShiti;
import com.model.TStu;
import com.model.TTea;
import com.opensymphony.xwork2.ActionSupport;

public class shitiAction extends ActionSupport
{
	private int id;
	private String mingcheng;
	private String fujian;
	private String fujianYuanshiming;
	 
	private String message;
	private String path;
	
	private TShitiDAO shitiDAO;
	
	public String shitiAdd()
	{
		TTea tea = (TTea)ServletActionContext.getRequest().getSession().getAttribute("tea");
		TShiti shiti=new TShiti();
		shiti.setMingcheng(mingcheng);
		shiti.setFujian(fujian);
		shiti.setFujianYuanshiming(fujianYuanshiming);
		shiti.setShijian(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		shiti.setDel("no");
		shiti.setStuId(tea.getTeaId());
		shiti.setStuName("老师");
		shitiDAO.save(shiti);
		this.setMessage("添加成功！");
		this.setPath("shitiMana.action");
		return "succeed";
	}
	
	public String shitiDel()
	{
		TShiti shiti=shitiDAO.findById(id);
		shiti.setDel("yes");
		shitiDAO.attachDirty(shiti);
		this.setMessage("删除成功！");
		this.setPath("shitiMana.action");
		return "succeed";
	}
	
	public String shitiMana()
	{
		String sql="from TShiti where del='no'";
		List shitiList=shitiDAO.getHibernateTemplate().find(sql);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("shitiList", shitiList);
		return ActionSupport.SUCCESS;
	}
	
	

	public String shitiAll()
	{
		String sql="from TShiti where del='no' and stuName = '老师' ";
		List shitiList=shitiDAO.getHibernateTemplate().find(sql);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("shitiList", shitiList);
		return ActionSupport.SUCCESS;
	}
	
	public String shitiDetailQian()
	{
		TShiti shiti=shitiDAO.findById(id);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("shiti", shiti);
		return ActionSupport.SUCCESS;
	}
	
	
	public String myShiti()
	{
		TStu stu = (TStu)ServletActionContext.getRequest().getSession().getAttribute("stu");
		String sql="from TShiti where del='no' and stuId = ? ";
		List shitiList=shitiDAO.getHibernateTemplate().find(sql,stu.getStuId());
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("shitiList", shitiList);
		return ActionSupport.SUCCESS;
	}
	public String myShitiDel()
	{
		TShiti shiti=shitiDAO.findById(id);
		shiti.setDel("yes");
		shitiDAO.attachDirty(shiti);
		this.setMessage("删除成功！");
		this.setPath("myShiti.action");
		return "succeed";
	}
	
	public String myShitiAdd()
	{
		TStu stu = (TStu)ServletActionContext.getRequest().getSession().getAttribute("stu");
		TShiti shiti=new TShiti();
		shiti.setMingcheng(mingcheng);
		shiti.setFujian(fujian);
		shiti.setFujianYuanshiming(fujianYuanshiming);
		shiti.setShijian(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		shiti.setDel("no");
		shiti.setStuId(stu.getStuId());
		shiti.setStuName(stu.getStuRealname());
		shitiDAO.save(shiti);
		HttpServletRequest request=ServletActionContext.getRequest();
		request.setAttribute("msg", "添加成功！");
		return "msg";
	}
	
	
	public String getFujian()
	{
		return fujian;
	}

	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}

	public String getFujianYuanshiming()
	{
		return fujianYuanshiming;
	}

	public TShitiDAO getshitiDAO()
	{
		return shitiDAO;
	}

	public void setshitiDAO(TShitiDAO shitiDAO)
	{
		this.shitiDAO = shitiDAO;
	}

	public void setFujianYuanshiming(String fujianYuanshiming)
	{
		this.fujianYuanshiming = fujianYuanshiming;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public TShitiDAO getShitiDAO()
	{
		return shitiDAO;
	}

	public void setShitiDAO(TShitiDAO shitiDAO)
	{
		this.shitiDAO = shitiDAO;
	}

	public String getMessage()
	{
		return message;
	}

	public void setMessage(String message)
	{
		this.message = message;
	}

	public String getMingcheng()
	{
		return mingcheng;
	}

	public void setMingcheng(String mingcheng)
	{
		this.mingcheng = mingcheng;
	}

	public String getPath()
	{
		return path;
	}

	public void setPath(String path)
	{
		this.path = path;
	}
	
}
