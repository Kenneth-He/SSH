package com.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;

import com.dao.TDocDAO;
import com.dao.TJingsaiDAO;
import com.model.TDoc;
import com.model.TJingsai;
import com.opensymphony.xwork2.ActionSupport;

public class jingsaiAction extends ActionSupport
{
	private Integer id;
	private String biaoti;
	private String neirong;
	private String shijian;
	 
	private String message;
	private String path;
	
	private TJingsaiDAO jingsaiDAO;
	
	public String jingsaiAdd()
	{
		TJingsai jingsai=new TJingsai();
		
		jingsai.setBiaoti(biaoti);
		jingsai.setNeirong(neirong);
		jingsai.setShijian(shijian);
		
		jingsaiDAO.save(jingsai);
		this.setMessage("操作成功!");
		this.setPath("jingsaiMana.action");
		return "succeed";
	}
	
	public String jingsaiDel()
	{
		TJingsai jingsai=jingsaiDAO.findById(id);
		jingsaiDAO.delete(jingsai);
		this.setMessage("删除成功！");
		this.setPath("jingsaiMana.action");
		return "succeed";
	}
	
	public String jingsaiMana()
	{
		String sql="from TJingsai";
		List jingsaiList=jingsaiDAO.getHibernateTemplate().find(sql);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("jingsaiList", jingsaiList);
		return ActionSupport.SUCCESS;
	}
	
	

	public String jingsaiAll()
	{
		String sql="from TJingsai";
		List jingsaiList=jingsaiDAO.getHibernateTemplate().find(sql);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("jingsaiList", jingsaiList);
		return ActionSupport.SUCCESS;
	}
	
	public String jingsaiDetailQian()
	{
		TJingsai jingsai=jingsaiDAO.findById(id);
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("jingsai", jingsai);
		return ActionSupport.SUCCESS;
	}

	public String getBiaoti()
	{
		return biaoti;
	}

	public void setBiaoti(String biaoti)
	{
		this.biaoti = biaoti;
	}

	public Integer getId()
	{
		return id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public TJingsaiDAO getJingsaiDAO()
	{
		return jingsaiDAO;
	}

	public void setJingsaiDAO(TJingsaiDAO jingsaiDAO)
	{
		this.jingsaiDAO = jingsaiDAO;
	}

	public String getMessage()
	{
		return message;
	}

	public void setMessage(String message)
	{
		this.message = message;
	}

	public String getNeirong()
	{
		return neirong;
	}

	public void setNeirong(String neirong)
	{
		this.neirong = neirong;
	}

	public String getPath()
	{
		return path;
	}

	public void setPath(String path)
	{
		this.path = path;
	}

	public String getShijian()
	{
		return shijian;
	}

	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}
	
}
