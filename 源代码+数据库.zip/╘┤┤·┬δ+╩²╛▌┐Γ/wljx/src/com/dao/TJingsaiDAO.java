package com.dao;

import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.model.TJingsai;

/**
 * Data access object (DAO) for domain model class TJingsai.
 * 
 * @see com.model.TJingsai
 * @author MyEclipse Persistence Tools
 */

public class TJingsaiDAO extends HibernateDaoSupport
{
	private static final Log log = LogFactory.getLog(TJingsaiDAO.class);

	protected void initDao()
	{
		// do nothing
	}

	public void save(TJingsai transientInstance)
	{
		log.debug("saving TJingsai instance");
		try
		{
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re)
		{
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(TJingsai persistentInstance)
	{
		log.debug("deleting TJingsai instance");
		try
		{
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re)
		{
			log.error("delete failed", re);
			throw re;
		}
	}

	public TJingsai findById(java.lang.Integer id)
	{
		log.debug("getting TJingsai instance with id: " + id);
		try
		{
			TJingsai instance = (TJingsai) getHibernateTemplate().get(
					"com.model.TJingsai", id);
			return instance;
		} catch (RuntimeException re)
		{
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(TJingsai instance)
	{
		log.debug("finding TJingsai instance by example");
		try
		{
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re)
		{
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value)
	{
		log.debug("finding TJingsai instance with property: " + propertyName
				+ ", value: " + value);
		try
		{
			String queryString = "from TJingsai as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re)
		{
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findAll()
	{
		log.debug("finding all TJingsai instances");
		try
		{
			String queryString = "from TJingsai";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re)
		{
			log.error("find all failed", re);
			throw re;
		}
	}

	public TJingsai merge(TJingsai detachedInstance)
	{
		log.debug("merging TJingsai instance");
		try
		{
			TJingsai result = (TJingsai) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re)
		{
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(TJingsai instance)
	{
		log.debug("attaching dirty TJingsai instance");
		try
		{
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re)
		{
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(TJingsai instance)
	{
		log.debug("attaching clean TJingsai instance");
		try
		{
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re)
		{
			log.error("attach failed", re);
			throw re;
		}
	}

	public static TJingsaiDAO getFromApplicationContext(ApplicationContext ctx)
	{
		return (TJingsaiDAO) ctx.getBean("TJingsaiDAO");
	}
}