package com.dao;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 *Created by pxc on 2018年5月20日 上午10:01:38
 * 
 */

public class DefenDao extends HibernateDaoSupport{
	

}
