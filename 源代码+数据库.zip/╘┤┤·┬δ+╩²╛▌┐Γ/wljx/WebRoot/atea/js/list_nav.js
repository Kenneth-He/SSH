var t;
t=outlookbar.addtitle('个人信息')
outlookbar.additem('个人信息',t,'/wljx/atea/userinfo/userinfo.jsp')


t=outlookbar.addtitle('课件发布')
outlookbar.additem('课件发布',t,'/wljx/atea/doc/docAdd.jsp')
outlookbar.additem('课件列表',t,'/wljx/docMana.action')


t=outlookbar.addtitle('案例管理')
outlookbar.additem('案例添加',t,'/wljx/atea/shipin/shipinAdd.jsp')
outlookbar.additem('案例列表',t,'/wljx/shipinMana.action')


t=outlookbar.addtitle('上传作业')
outlookbar.additem('作业添加',t,'/wljx/atea/shiti/shitiAdd.jsp')
outlookbar.additem('作业列表',t,'/wljx/shitiMana.action')

t=outlookbar.addtitle('测试题目')
outlookbar.additem('题目管理',t,'/wljx/timuMana.action')
outlookbar.additem('题目录入',t,'/wljx/admin/timu/timuAdd.jsp')

t=outlookbar.addtitle('讨论管理')
outlookbar.additem('讨论管理',t,'/wljx/liuyanhuifu.action')

t=outlookbar.addtitle('得分列表')
outlookbar.additem('得分列表',t,'/wljx/getDefenList.action')

t=outlookbar.addtitle('退出系统') 
outlookbar.additem('安全退出',t,'/wljx/login.jsp')