var t;
t=outlookbar.addtitle('修改密码')
outlookbar.additem('密码修改',t,'/wljx/admin/userinfo/userPw.jsp')


t=outlookbar.addtitle('老师管理')
outlookbar.additem('老师管理',t,'/wljx/teaMana.action')
outlookbar.additem('老师录入',t,'/wljx/admin/tea/teaAdd.jsp')


t=outlookbar.addtitle('学生管理')
outlookbar.additem('学生管理',t,'/wljx/stuMana.action')

t=outlookbar.addtitle('讨论管理')
outlookbar.additem('讨论管理',t,'/wljx/liuyanMana.action')


t=outlookbar.addtitle('公告管理')
outlookbar.additem('公告管理',t,'/wljx/gonggaoMana.action')

/*
t=outlookbar.addtitle('测试题目')
outlookbar.additem('题目管理',t,'/wljx/timuMana.action')
outlookbar.additem('题目录入',t,'/wljx/admin/timu/timuAdd.jsp')
*/

t=outlookbar.addtitle('教学计划')
outlookbar.additem('教学计划管理',t,'/wljx/jingsaiMana.action')
outlookbar.additem('教学计划录入',t,'/wljx/admin/jingsai/jingsaiAdd.jsp')


t=outlookbar.addtitle('退出系统') 
outlookbar.additem('安全退出',t,'/wljx/login.jsp')